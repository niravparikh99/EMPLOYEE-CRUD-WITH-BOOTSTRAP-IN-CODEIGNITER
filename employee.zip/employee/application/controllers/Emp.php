<?php
class Emp extends CI_Controller {
 
    public function __construct()
    {
        parent::__construct();
        $this->load->model('empmodel');
        $this->load->helper('url_helper');
    }
 
    public function index()
    {
        $data['emp'] = $this->empmodel->getRec();
        $data['firstName'] = 'Emp archive';
 
        $this->load->view('templates/header', $data);
        $this->load->view('record/index', $data);
        $this->load->view('templates/footer');
    }
 
    public function viewItems($firstName = NULL)
    {
        $data['emp_detail'] = $this->empmodel->getRec($firstName);
        
        if (empty($data['emp_detail']))
        {
            show_404();
        }
 
        $data['fnm'] = $data['emp_detail']['firstName'];
 
        $this->load->view('templates/header', $data);
        $this->load->view('record/viewEmp', $data);
        $this->load->view('templates/footer');
    }
    
    public function addItems()
    {
        $this->load->helper('form');
        $this->load->library('form_validation');
 
        $data['fnm'] = 'Add Record';
       
        $this->form_validation->set_rules('firstName', 'firstName', 'required');
        $this->form_validation->set_rules('lastName', 'lastName', 'required');
        $this->form_validation->set_rules('genDer', 'genDer', 'required');
        $this->form_validation->set_rules('dateOfBirth','dateOfBirth', 'required');
        $this->form_validation->set_rules('addRess', 'addRess', 'required');
        $this->form_validation->set_rules('ciTy', 'ciTy', 'required');
 
        if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('templates/header', $data);
            $this->load->view('record/addEmp');
            $this->load->view('templates/footer');
         }
        else
        {
            $this->empmodel->setRec();
            redirect( base_url() . 'index.php/emp');
        }
    }
     public function editItems()
    {
        $id = $this->uri->segment(3);
        
        if (empty($id))
        {
            show_404();
        }
        $this->load->library('form_validation');
        
        $data['fnm'] = 'Edit Record';        
        $data['emp_detail'] = $this->empmodel->getRecById($id);
        
        $this->form_validation->set_rules('firstName', 'firstName', 'required');
        $this->form_validation->set_rules('lastName', 'lastName', 'required');
        $this->form_validation->set_rules('genDer', 'genDer', 'required');
        $this->form_validation->set_rules('dateOfBirth' , 'dateOfBirth' , 'required');
        $this->form_validation->set_rules('addRess', 'addRess', 'required');
        $this->form_validation->set_rules('ciTy', 'ciTy', 'required'); 

        if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('templates/header', $data);
            $this->load->view('record/editEmp', $data);
            $this->load->view('templates/footer');
        }
        else
        {
	    
            $this->empmodel->setRec($id);
            redirect( base_url() . 'index.php/emp');
        }
    }
    
    public function deleteItems()
    {
        $id = $this->uri->segment(3);
        
        if (empty($id))
        {
            show_404();
        }
                
        $emp_detail = $this->empmodel->getRecbyid($id);
        $this->empmodel->deleteRec($id);        
        redirect( base_url() . 'index.php/emp');        
    }
}
