
<?php echo validation_errors(); ?>
 
<?php echo form_open('emp/editItems/'.$emp_detail['id']); ?>
    
<form class="form-horizontal">
  <fieldset>
    <legend>Edit Employee</legend>
     <div class="form-group">
              <label for="inputTitle" class="col-lg-1 control-label">First Name</label>
       <div class="col-lg-3">
              <input type="text" class="form-control" name="firstName" value="<?php echo $emp_detail['firstName'] ?>" >
       </div>
            <label for="inputTitle" class="col-lg-1 control-label">Last Name</label>
       <div class="col-lg-3">
             <input type="text" class="form-control" name="lastName"  value="<?php echo $emp_detail['lastName'] ?>">
       </div>
       <br><br><br> <label class="col-lg-1 control-label">Gender</label>
        <div class="col-lg-4">
          <div class="radio">
             <label>
                     <input type="radio" name="genDer"  value="1" checked="" /> Male
             </label>
             <label>
                     <input type="radio" name="genDer"  value="0"  /> Female            
             </label>
          </div>
        </div>

              
           <div class="container">
             <label>Date of Birth</label>
               <div class="container-fluid">
                 <div class="row"> 
                   <div class="col-md-3 col-sm-3 col-xs-12">
                        <form method="post">
                        <div class="form-group"> 
                            <input class="form-control" id="date" name="dateOfBirth"  type="text" value="<?php echo $emp_detail['dateOfBirth'] ?>"/>
                        </div>
                      </form>
                   </div>
                 </div>    
               </div>
             </div>                  

             <label  class="col-lg-1 control-label">Address</label>
               <div class="col-lg-3">
                  <input type="text" class="form-control" name="addRess"  value="<?php echo $emp_detail['addRess'] ?>">
               </div>   
               <label for="select" class="col-lg-1 control-label">City</label>
        <div class="col-lg-2">
        <select class="form-control" name="ciTy" value="<?php echo $emp_detail['ciTy'] ?>">
          <option>Ahmedabad</option>
          <option>Baroda</option>
          <option>Surat</option>
          <option>Rajkot</option>
          <option>Jamnagar</option>
        </select>
      </div>
         <div class="col-lg-10 col-lg-offset-1"><br>
         <button type="submit" class="btn btn-primary">Edit</button>
         <button type="reset" class="btn btn-default">Cancel</button>
      </div>
    
  </fieldset>
</form>




