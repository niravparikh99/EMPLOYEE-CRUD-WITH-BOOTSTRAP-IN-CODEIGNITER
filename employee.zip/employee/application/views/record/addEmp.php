
 
<?php echo validation_errors(); ?>
 
<?php echo form_open('emp/addItems'); ?>    
   

<form class="form-horizontal">
  <fieldset>
    <legend>Add Employee</legend>
     <div class="form-group">
              <label for="inputTitle" class="col-lg-1 control-label">First Name</label>
       <div class="col-lg-3">
              <input type="text" class="form-control" name="firstName"  placeholder="First name">
       </div>
               <label for="inputTitle" class="col-lg-1 control-label">Last Name</label>
       <div class="col-lg-3">
             <input type="text" class="form-control" name="lastName"  placeholder="Last name">
       </div>
       <br><br><br> <label class="col-lg-1 control-label">Gender</label>
        <div class="col-lg-4">
          <div class="radio">
             <label>
                     <input type="radio" name="genDer" id="optionsRadios1" value="Male" checked="">
                       Male
             </label>
             <label>
                     <input type="radio" name="genDer" id="optionsRadios2" value="Female">
                      Female            
             </label>
          </div>
        </div>
     
            <div class="container">
             <label>Date of Birth</label>
               <div class="container-fluid">
                 <div class="row"> 
                   <div class="col-md-3 col-sm-3 col-xs-12">
                        <form method="post">
                        
                          <div class="form-group"> 
                            <input class="form-control" id="date" name="dateOfBirth" placeholder="YYYY-MM-DD" type="text"/>
                        </div>
                      </form>
                   </div>
                 </div>    
               </div>
             </div>

          
              <label for="Text" class="col-lg-1 control-label">Address</label>
               <div class="col-lg-3">
                   <textarea class="form-control" rows="7" name="addRess" id="add">
                   </textarea>
               </div>   
      
      <label for="select" class="col-lg-1 control-label">City</label>
      <div class="col-lg-2">
        <select class="form-control" id="select" name="ciTy">
          <option>Ahmedabad</option>
          <option>Baroda</option>
          <option>Surat</option>
          <option>Rajkot</option>
          <option>Jamnagar</option>
        </select>
      </div>
     
    
      <div class="col-lg-10 col-lg-offset-1"><br>
         <button type="submit" class="btn btn-primary">Save</button>
         <button type="reset" class="btn btn-default">Cancel</button>
      </div>
    

  </fieldset>
</form>






