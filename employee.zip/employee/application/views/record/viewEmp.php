
<table class="table table-striped table-hover ">
<legend>View Records</legend>
  <thead>
  <tr>
      <th>ID</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Gender</th>
      <th>Date of Birth</th>
      <th>Address</th>
      <th>City</th>
  </tr>
  </thead>
  <tbody>
   <tr class="warning">
      <td> <label class="col-lg control-label"> <?php echo $emp_detail['id']?></label></td>
      <td> <label class="col-lg control-label"> <?php echo $emp_detail['firstName']?></label></td>
      <td><label class="col-lg  control-label"><?php echo $emp_detail['lastName']?></label></td>
      <td><label class="col-lg  control-label"><?php echo $emp_detail['genDer']?></label></td>
      <td><label class="col-lg  control-label"><?php echo $emp_detail['dateOfBirth']?></label></td>
      <td><label class="col-lg  control-label"><?php echo $emp_detail['addRess']?></label></td>
      <td><label class="col-lg  control-label"><?php echo $emp_detail['ciTy']?></label></td>
   </tr>

  </tbody>
</table> 
