
 <table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>ID</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Gender</th>
      <th>Date of Birth</th>
      <th>Address</th>
      <th>City</th>
      <th>Action</th>
      </tr>
  </thead>

<?php foreach ($emp as $emp_detail): ?>
      <tr class="active">
            <td><?php echo $emp_detail['id'];?></td>
            <td><?php echo $emp_detail['firstName']; ?></td>
            <td><?php echo $emp_detail['lastName']; ?></td>
            <td><?php echo $emp_detail['genDer']; ?></td>
            <td><?php echo $emp_detail['dateOfBirth']; ?></td>
            <td><?php echo $emp_detail['addRess']; ?></td>
            <td><?php echo $emp_detail['ciTy']; ?></td>
            <td>
                <a href="<?php echo site_url('emp/viewItems/'.$emp_detail['firstName']); ?>" class="btn btn-info">View</a> | 
                <a href="<?php echo site_url('emp/editItems/'.$emp_detail['id']); ?>" class="btn btn-info">Edit</a> | 
                <a href="<?php echo site_url('emp/deleteItems/'.$emp_detail['id']); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-info">Delete</a>
            </td>
        </tr>
<?php endforeach; ?>
</table>

